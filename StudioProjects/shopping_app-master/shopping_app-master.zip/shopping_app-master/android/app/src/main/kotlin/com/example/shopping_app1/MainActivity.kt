package com.example.shopping_app1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
