class AssetImages{
 static AssetImages instance=AssetImages();


  static const String _imagesPath="assets/images/";
  final String welcomeImage="$_imagesPath/vector.png";

}